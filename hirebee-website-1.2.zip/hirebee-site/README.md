# HireBee website

Plain HTML, no build step. Hosted free on GitHub Pages.

## 1. Fill in your settings
Open `config.js` and set:
- `botUsername`: your bot's username without @
- `contactEmail`: where users and Whish can reach you
- `contactPhone`: optional
- `tonAddress`: your Keeper wallet's **public** address (UQ… or EQ…). Leave empty to hide the USDT option.

Never put a private key or recovery phrase in this folder: everything here is public.
Until `botUsername` and `contactEmail` are set, a red reminder bar shows at the top of every page.

## 2. Put it online with GitHub Pages
1. On github.com, create a new **public** repository named `hirebee`.
2. **Add file → Upload files**, drag in everything in this folder, then **Commit changes**.
3. **Settings → Pages → Build and deployment**: Source "Deploy from a branch", branch `main`, folder `/ (root)`, **Save**.
4. After about a minute the site is live at `https://aymanaghi.github.io/hirebee/`.

## 3. Connect the bot
In the bot's `.env`:
```
WEBSITE_CHECKOUT_URL=https://aymanaghi.github.io/hirebee/pay.html
```
The bot adds each user's order code to that link (`?code=…&plan=…`).

## Logo and share image
`favicon.svg`, `favicon-32.png`, `apple-touch-icon.png` and `og-share.png` (the preview card when the link is shared).
`og-share.png` is referenced as https://aymanaghi.github.io/hirebee/og-share.png: change that line in each page's head if you move to your own domain.

## Pages
- `index.html`: home, features, pricing, FAQ
- `pay.html`: payment page (USDT on TON via Keeper, Whish, Telegram Stars)
- `terms.html`, `privacy.html`, `refunds.html`, `contact.html`

Read the terms, privacy and refund pages before publishing and change anything that doesn't match how you work.
They're a plain-language starting point, not legal advice.
